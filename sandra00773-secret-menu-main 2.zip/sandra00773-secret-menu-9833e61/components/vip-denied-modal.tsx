"use client";

import { useEffect, useRef } from "react";
import { Cross } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const CHOIR_NOTES = [130.81, 196, 261.63, 329.63, 392];

type VipDeniedModalProps = {
  open: boolean;
  onClose: () => void;
};

export function VipDeniedModal({ open, onClose }: VipDeniedModalProps) {
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;

    const AudioContextClass = window.AudioContext;
    if (!AudioContextClass) return;

    const context = new AudioContextClass();
    const master = context.createGain();
    master.gain.setValueAtTime(0.0001, context.currentTime);
    master.gain.exponentialRampToValueAtTime(0.12, context.currentTime + 1.4);

    const filter = context.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 1600;
    filter.Q.value = 0.7;
    master.connect(filter);
    filter.connect(context.destination);

    const oscillators: OscillatorNode[] = [];

    CHOIR_NOTES.forEach((frequency, index) => {
      [0, 6].forEach((detune) => {
        const oscillator = context.createOscillator();
        oscillator.type = index === 0 ? "triangle" : "sine";
        oscillator.frequency.value = frequency;
        oscillator.detune.value = detune;

        const voiceGain = context.createGain();
        voiceGain.gain.value = index === 0 ? 0.35 : 0.22;

        const vibrato = context.createOscillator();
        vibrato.frequency.value = 4.4 + index * 0.25;
        const vibratoDepth = context.createGain();
        vibratoDepth.gain.value = 3.5;
        vibrato.connect(vibratoDepth);
        vibratoDepth.connect(oscillator.detune);
        vibrato.start();

        oscillator.connect(voiceGain);
        voiceGain.connect(master);
        oscillator.start();

        oscillators.push(oscillator, vibrato);
      });
    });

    void context.resume();

    return () => {
      const now = context.currentTime;
      master.gain.cancelScheduledValues(now);
      master.gain.setTargetAtTime(0.0001, now, 0.15);
      oscillators.forEach((oscillator) => {
        oscillator.stop(now + 0.8);
      });
      window.setTimeout(() => {
        void context.close();
      }, 1000);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    dialogRef.current?.focus();

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      ref={dialogRef}
      role="dialog"
      aria-modal="true"
      aria-labelledby="vip-denied-title"
      tabIndex={-1}
      className="fixed inset-0 z-[100] flex min-h-svh flex-col items-center justify-center overflow-y-auto bg-white px-5 py-12 text-center animate-in fade-in zoom-in-95 duration-300 focus:outline-none"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-4 border border-red-200 sm:inset-6"
      />
      <div className="relative flex w-full max-w-xl flex-col items-center">
        <Cross className="size-16 text-red-600 sm:size-20" strokeWidth={1.4} />
        <h2
          id="vip-denied-title"
          className="mt-6 font-serif text-5xl font-semibold tracking-[0.14em] text-red-700 sm:text-7xl"
        >
          ОТКАЗАНО
        </h2>
        <p className="mt-8 max-w-md text-base leading-relaxed text-neutral-700 sm:text-lg">
          Сын мой, это тяжкий грех. Господь не одобряет. Но он прощает
        </p>
        <div className="mt-8 w-full max-w-md border-y border-neutral-300 py-5">
          <p className="text-[0.62rem] uppercase tracking-[0.3em] text-neutral-500">
            Ближайший храм
          </p>
          <p className="mt-2 text-sm leading-relaxed text-neutral-800">
            Храм Богоявления, пер. Чижевских, Лошица, Минск
          </p>
          <p className="mt-1 text-xs uppercase tracking-[0.16em] text-neutral-500">
            рядом с Лошицким парком
          </p>
        </div>
        <p className="mt-8 max-w-md font-serif text-xl italic leading-relaxed text-neutral-900 sm:text-2xl">
          «Господи Иисусе Христе, сыне Божий, помилуй мя, грешного или грешную.
          Амин»
        </p>
        <Button
          type="button"
          onClick={onClose}
          className={cn(
            "mt-10 h-12 rounded-full bg-red-700 px-8 text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-white hover:bg-red-800 focus-visible:ring-red-600"
          )}
        >
          Я всё понял. Я буду молиться
        </Button>
      </div>
    </div>
  );
}
