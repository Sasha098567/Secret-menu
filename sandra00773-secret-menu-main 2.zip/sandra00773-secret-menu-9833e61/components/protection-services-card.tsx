"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ShieldCheck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { protectionService } from "@/lib/data";
import { cn } from "@/lib/utils";

export function ProtectionServicesCard() {
  const [isPrayerOpen, setIsPrayerOpen] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  const closePrayer = useCallback(() => {
    setIsPrayerOpen(false);
    triggerRef.current?.focus();
  }, []);

  useEffect(() => {
    if (!isPrayerOpen) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    dialogRef.current?.focus();

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closePrayer();
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isPrayerOpen, closePrayer]);

  return (
    <article className="mt-14 border border-gold/30 bg-black/25 p-6 sm:p-8">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <p className="flex items-center gap-3 text-[0.62rem] uppercase tracking-[0.3em] text-gold-muted">
            <span className="flex size-8 items-center justify-center rounded-full border border-gold/40 text-gold">
              <ShieldCheck className="size-4" />
            </span>
            {protectionService.title}
          </p>
          <h3 className="mt-4 font-serif text-2xl font-medium tracking-wide text-foreground sm:text-3xl">
            {protectionService.name}
          </h3>
          <p className="mt-3 max-w-xl text-sm leading-relaxed text-foreground/70">
            {protectionService.description}
          </p>
          <p className="mt-4 max-w-xl font-serif text-lg text-gold">
            {protectionService.price}
          </p>
        </div>

        <Button
          ref={triggerRef}
          type="button"
          aria-haspopup="dialog"
          onClick={() => setIsPrayerOpen(true)}
          className={cn(
            "h-11 shrink-0 gap-2 rounded-full px-6 text-[0.68rem] font-semibold uppercase tracking-[0.18em]"
          )}
        >
          Прочитать молитву
        </Button>
      </div>

      {isPrayerOpen ? (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-black/80 px-5 py-12 animate-in fade-in duration-300"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) closePrayer();
          }}
        >
          <div
            ref={dialogRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="protection-prayer-title"
            tabIndex={-1}
            className="relative w-full max-w-lg border border-gold/35 bg-wine-deep p-7 text-center shadow-2xl animate-in zoom-in-95 duration-300 focus:outline-none sm:p-10"
          >
            <button
              type="button"
              onClick={closePrayer}
              aria-label="Закрыть молитву"
              className="absolute right-4 top-4 flex size-8 items-center justify-center rounded-full text-foreground/50 transition-colors hover:text-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60"
            >
              <X className="size-4" />
            </button>

            <p className="text-[0.62rem] uppercase tracking-[0.32em] text-gold-muted">
              Молитва о защите
            </p>
            <h4
              id="protection-prayer-title"
              className="mt-3 font-serif text-2xl font-medium tracking-wide text-foreground sm:text-3xl"
            >
              Противогаз и терпение
            </h4>

            <div aria-hidden className="mx-auto mt-6 h-px w-16 bg-gold/40" />

            <p className="mt-6 font-serif text-lg leading-relaxed text-foreground/85 sm:text-xl">
              «{protectionService.prayer}»
            </p>

            <Button
              type="button"
              onClick={closePrayer}
              className="mt-8 h-11 rounded-full px-7 text-[0.68rem] font-semibold uppercase tracking-[0.18em]"
            >
              Вернуться к каталогу
            </Button>
          </div>
        </div>
      ) : null}
    </article>
  );
}
