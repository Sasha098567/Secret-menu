"use client";

import { Check, Lightbulb, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

type CustomIdeaCardProps = {
  idea: string;
  isSelected: boolean;
  onIdeaChange: (value: string) => void;
  onAdd: () => void;
  onRemove: () => void;
};

export function CustomIdeaCard({
  idea,
  isSelected,
  onIdeaChange,
  onAdd,
  onRemove,
}: CustomIdeaCardProps) {
  const trimmedIdea = idea.trim();

  return (
    <article
      className={cn(
        "mt-14 border p-6 transition-colors duration-300 sm:p-8",
        isSelected
          ? "border-gold/60 bg-gold/[0.06]"
          : "border-gold/25 bg-black/25"
      )}
    >
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="max-w-xl">
          <p className="flex items-center gap-2 text-[0.62rem] uppercase tracking-[0.32em] text-gold-muted">
            <Lightbulb className="size-3.5 text-gold-muted" />
            Твой вариант
          </p>
          <h3 className="mt-3 font-serif text-2xl font-medium tracking-wide text-foreground sm:text-3xl">
            Своя идея
          </h3>
          <p className="mt-3 text-sm leading-relaxed text-foreground/60">
            Придумал, куда сходить или как провести время? Впиши свой вариант —
            он попадет в заявку, а цену обсудим по договорённости.
          </p>
        </div>

        {isSelected ? (
          <span className="inline-flex shrink-0 items-center gap-1 text-[0.58rem] font-medium uppercase tracking-[0.18em] text-gold">
            <Check className="size-3" />
            Выбрано
          </span>
        ) : null}
      </div>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <Input
          value={idea}
          onChange={(event) => onIdeaChange(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              event.preventDefault();

              if (trimmedIdea && !isSelected) onAdd();
            }
          }}
          aria-label="Своя идея"
          placeholder="Например: пикник на закате у водохранилища"
          className="h-11 flex-1 rounded-none border-gold/30 bg-wine-deep px-3 text-sm text-foreground placeholder:text-foreground/35 focus-visible:border-gold focus-visible:ring-2 focus-visible:ring-gold/40"
        />

        {isSelected ? (
          <Button
            type="button"
            variant="outline"
            onClick={onRemove}
            className="h-11 shrink-0 gap-2 rounded-full border-gold/40 bg-transparent px-5 text-[0.66rem] font-semibold uppercase tracking-[0.16em] text-gold hover:bg-gold/10 hover:text-gold"
          >
            <X className="size-4" />
            Убрать из заявки
          </Button>
        ) : (
          <Button
            type="button"
            onClick={onAdd}
            disabled={!trimmedIdea}
            className="h-11 shrink-0 gap-2 rounded-full px-5 text-[0.66rem] font-semibold uppercase tracking-[0.16em]"
          >
            <Plus className="size-4" />
            Добавить в заявку
          </Button>
        )}
      </div>

      <p className="mt-3 text-xs leading-relaxed text-foreground/45">
        {isSelected
          ? "Твоя идея уже в заявке. Если передумаешь — убери её здесь или в форме."
          : "Цену у этой позиции не показываем — всё по договорённости."}
      </p>
    </article>
  );
}
