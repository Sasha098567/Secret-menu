"use client";

import { useCallback, useState } from "react";
import { Check } from "lucide-react";
import { hasPrice, serviceCatalog, vipService } from "@/lib/data";
import { cn } from "@/lib/utils";
import { VipDeniedModal } from "@/components/vip-denied-modal";
import { ProtectionServicesCard } from "@/components/protection-services-card";
import { VenueRules } from "@/components/venue-rules";
import { ServiceRequestForm } from "@/components/service-request-form";
import { RefuseButton } from "@/components/refuse-button";
import { CustomIdeaCard } from "@/components/custom-idea-card";

export function ServiceCatalog() {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [customIdea, setCustomIdea] = useState("");
  const [isCustomIdeaSelected, setIsCustomIdeaSelected] = useState(false);
  const [isVipOpen, setIsVipOpen] = useState(false);
  const closeVip = useCallback(() => setIsVipOpen(false), []);

  const handleCustomIdeaChange = useCallback((value: string) => {
    setCustomIdea(value);

    if (!value.trim()) setIsCustomIdeaSelected(false);
  }, []);

  const addCustomIdea = useCallback(() => {
    if (!customIdea.trim()) return;

    setIsCustomIdeaSelected(true);
  }, [customIdea]);

  const removeCustomIdea = useCallback(
    () => setIsCustomIdeaSelected(false),
    []
  );

  const toggleCustomIdea = useCallback(
    () => setIsCustomIdeaSelected((current) => !current),
    []
  );

  const toggleService = useCallback((serviceId: string) => {
    setSelectedIds((current) =>
      current.includes(serviceId)
        ? current.filter((id) => id !== serviceId)
        : [...current, serviceId]
    );
  }, []);

  const selectService = useCallback((serviceId: string) => {
    setSelectedIds((current) =>
      current.includes(serviceId) ? current : [...current, serviceId]
    );
  }, []);

  return (
    <section
      id="catalog"
      className="relative scroll-mt-14 border-t border-gold/15 bg-wine-deep"
    >
      <div className="mx-auto max-w-5xl px-6 py-20 sm:py-28">
        <div className="text-center">
          <p className="text-[0.68rem] uppercase tracking-[0.42em] text-gold-muted">
            Полное меню
          </p>
          <h2 className="mt-4 font-serif text-3xl font-medium tracking-wide text-foreground sm:text-4xl">
            Каталог услуг
          </h2>
        </div>

        <div className="mt-14 grid gap-12 md:grid-cols-2 md:gap-16">
          {serviceCatalog.map((category) => (
            <article key={category.id}>
              <header className="flex items-baseline justify-between gap-4 border-b border-gold/25 pb-4">
                <h3 className="font-serif text-2xl font-medium tracking-wide text-foreground sm:text-3xl">
                  {category.title}
                </h3>
                <span
                  aria-hidden
                  className="font-serif text-sm italic text-gold-muted"
                >
                  {category.numeral}
                </span>
              </header>

              <ul className="mt-1">
                {category.services.map((service) => {
                  const isSelected = selectedIds.includes(service.id);

                  return (
                    <li key={service.id}>
                      <button
                        type="button"
                        aria-pressed={isSelected}
                        onClick={() => toggleService(service.id)}
                        className={cn(
                          "group flex w-full items-start gap-4 border-b border-gold/10 px-3 py-4 text-left transition-colors duration-300 last:border-b-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60",
                          isSelected
                            ? "border-gold/40 bg-gold/[0.08]"
                            : "hover:bg-gold/[0.04]"
                        )}
                      >
                        <span className="min-w-0 flex-1">
                          <span
                            className={cn(
                              "block text-sm leading-relaxed transition-colors sm:text-base",
                              isSelected
                                ? "text-gold"
                                : "text-foreground/85 group-hover:text-foreground"
                            )}
                          >
                            {service.name}
                          </span>
                          <span className="mt-1 block text-xs leading-relaxed text-foreground/50">
                            {service.description}
                          </span>
                        </span>

                        <span className="shrink-0 text-right">
                          {hasPrice(service) ? (
                            <span
                              className={cn(
                                "block font-serif text-lg",
                                isSelected ? "text-gold" : "text-gold-muted"
                              )}
                            >
                              {service.price} $
                            </span>
                          ) : null}
                          {isSelected ? (
                            <span className="mt-1 inline-flex items-center gap-1 text-[0.58rem] font-medium uppercase tracking-[0.18em] text-gold">
                              <Check className="size-3" />
                              Выбрано
                            </span>
                          ) : null}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </article>
          ))}
        </div>

        <CustomIdeaCard
          idea={customIdea}
          isSelected={isCustomIdeaSelected}
          onIdeaChange={handleCustomIdeaChange}
          onAdd={addCustomIdea}
          onRemove={removeCustomIdea}
        />

        <RefuseButton selectedIds={selectedIds} onAutoSelect={selectService} />

        <article className="mt-14">
          <button
            type="button"
            aria-haspopup="dialog"
            onClick={() => setIsVipOpen(true)}
            className="group flex w-full flex-col gap-5 border border-gold/30 bg-black/25 p-6 text-left transition-colors duration-300 hover:border-gold/60 hover:bg-gold/[0.05] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60 sm:flex-row sm:items-center sm:justify-between sm:p-8"
          >
            <span className="min-w-0">
              <span className="flex items-center gap-3 text-[0.62rem] uppercase tracking-[0.3em] text-gold-muted">
                <span className="rounded-full border border-gold/40 px-2.5 py-1 text-gold">
                  {vipService.tag}
                </span>
                Отдельная позиция
              </span>
              <span className="mt-4 block font-serif text-2xl font-medium tracking-wide text-foreground transition-colors duration-300 group-hover:text-gold sm:text-3xl">
                {vipService.name}
              </span>
              <span className="mt-2 block max-w-md text-xs leading-relaxed text-foreground/50">
                {vipService.description}
              </span>
            </span>
            <span className="shrink-0 text-[0.62rem] uppercase tracking-[0.24em] text-gold-muted transition-colors duration-300 group-hover:text-gold">
              Открыть VIP
            </span>
          </button>
        </article>

        <ProtectionServicesCard />

        <VenueRules />

        <ServiceRequestForm
          selectedIds={selectedIds}
          onToggleService={toggleService}
          customIdea={customIdea}
          isCustomIdeaSelected={isCustomIdeaSelected}
          onToggleCustomIdea={toggleCustomIdea}
        />
      </div>

      <VipDeniedModal open={isVipOpen} onClose={closeVip} />
    </section>
  );
}
