"use client";

import { useState } from "react";
import Image from "next/image";
import { ArrowRight, EyeOff, LockKeyhole, Sparkles } from "lucide-react";
import { buttonVariants } from "@/components/ui/button-variants";
import { ScrollAnchor } from "@/components/scroll-anchor";
import { cn } from "@/lib/utils";

type Stage = "sealed" | "question" | "revealed";

const answers = ["С первой минуты", "Не выходит из головы", "И сейчас тоже"];

export function ForYou() {
  const [stage, setStage] = useState<Stage>("sealed");

  return (
    <section
      id="for-you"
      className="relative scroll-mt-14 overflow-hidden border-t border-gold/20 bg-wine-deep"
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-0 h-[32rem] w-[32rem] -translate-x-1/2 -translate-y-1/3 rounded-full bg-[radial-gradient(circle,oklch(0.5_0.14_18/0.45)_0%,transparent_70%)] blur-2xl" />
        <div className="absolute -right-24 bottom-0 h-80 w-80 rounded-full bg-[radial-gradient(circle,oklch(0.78_0.1_82/0.12)_0%,transparent_70%)] blur-2xl" />
        <div className="absolute inset-x-4 top-4 bottom-4 border border-gold/15 sm:inset-x-8 sm:top-8 sm:bottom-8" />
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/60 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl px-5 py-20 sm:px-6 sm:py-28">
        <div className="text-center">
          <p className="mx-auto flex max-w-max items-center gap-3 text-[0.68rem] uppercase tracking-[0.42em] text-gold-muted">
            <span aria-hidden className="h-px w-8 bg-gold/50" />
            Лично для Ника
            <span aria-hidden className="h-px w-8 bg-gold/50" />
          </p>
          <h2 className="mt-5 font-serif text-4xl font-medium tracking-wide text-foreground sm:text-5xl">
            Только для тебя
          </h2>
          <p className="mx-auto mt-5 max-w-md text-sm leading-relaxed text-foreground/65 sm:text-base">
            Один кадр. Одна печать. И ни одного зрителя, кроме тебя.
          </p>
        </div>

        <div className="mt-12 flex justify-center sm:mt-14">
          <div className="relative w-full max-w-md">
            <div
              aria-hidden
              className="absolute -inset-4 rounded-[2.25rem] bg-[radial-gradient(circle,oklch(0.78_0.1_82/0.3)_0%,transparent_70%)] blur-2xl"
            />

            <div className="relative rounded-[2rem] bg-gradient-to-br from-gold/80 via-gold/25 to-gold/70 p-[2px] shadow-[0_0_60px_-15px_oklch(0.78_0.1_82/0.55)]">
              <div className="rounded-[calc(2rem-2px)] bg-wine-deep p-2.5 sm:p-3.5">
                {stage === "revealed" ? (
                  <div className="animate-in fade-in zoom-in-95 duration-700">
                    <div className="relative overflow-hidden rounded-[1.4rem] border border-gold/45">
                      <div className="relative aspect-[4/3]">
                        <Image
                          src="/assets/IMG_6690.jpeg"
                          alt="Кадр, который Александра оставила только для Ника"
                          width={1206}
                          height={891}
                          sizes="(min-width: 640px) 28rem, 90vw"
                          className="size-full object-cover"
                        />
                        <div
                          aria-hidden
                          className="absolute inset-0 bg-gradient-to-t from-wine-deep/75 via-transparent to-transparent"
                        />
                        <p className="absolute bottom-4 left-4 right-4 font-serif text-sm italic text-foreground/90 sm:text-base">
                          «Вот теперь ты знаешь, о чём я молчу весь день.»
                        </p>
                      </div>
                    </div>

                    <div className="px-2 pb-1 pt-6 text-center">
                      <p className="text-[0.6rem] uppercase tracking-[0.34em] text-gold-muted">
                        Александра
                      </p>
                      <button
                        type="button"
                        onClick={() => setStage("sealed")}
                        className={cn(
                          buttonVariants({ variant: "outline", size: "lg" }),
                          "mt-5 h-11 gap-2 rounded-full border-gold/40 bg-transparent px-6 text-[0.68rem] font-semibold uppercase tracking-[0.2em] text-foreground/80 hover:bg-gold/10 hover:text-gold"
                        )}
                      >
                        <EyeOff className="size-4" />
                        Скрыть фото
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="relative flex min-h-[27rem] flex-col items-center justify-center overflow-hidden rounded-[1.4rem] border border-gold/30 bg-[radial-gradient(circle_at_50%_20%,oklch(0.3_0.09_14/0.7)_0%,oklch(0.12_0.025_15/0.9)_70%)] px-5 py-12 text-center sm:min-h-[31rem] sm:px-8">
                    <span
                      aria-hidden
                      className="absolute left-4 top-4 size-5 border-l border-t border-gold/40"
                    />
                    <span
                      aria-hidden
                      className="absolute right-4 top-4 size-5 border-r border-t border-gold/40"
                    />
                    <span
                      aria-hidden
                      className="absolute bottom-4 left-4 size-5 border-b border-l border-gold/40"
                    />
                    <span
                      aria-hidden
                      className="absolute bottom-4 right-4 size-5 border-b border-r border-gold/40"
                    />

                    {stage === "sealed" ? (
                      <div className="relative">
                        <div className="relative mx-auto flex size-24 items-center justify-center rounded-full border border-gold/40 bg-black/20 shadow-[0_0_40px_-12px_oklch(0.78_0.1_82/0.5)]">
                          <div className="flex size-20 items-center justify-center rounded-full border border-gold/30">
                            <span className="font-serif text-4xl leading-none text-gold">
                              A
                            </span>
                          </div>
                          <span className="absolute -bottom-1 -right-1 flex size-8 items-center justify-center rounded-full bg-gold text-primary-foreground shadow-lg">
                            <LockKeyhole className="size-4" />
                          </span>
                        </div>

                        <p className="mt-8 flex items-center justify-center gap-2 text-[0.6rem] uppercase tracking-[0.34em] text-gold-muted">
                          <Sparkles className="size-3" />
                          Запечатано Александрой
                        </p>

                        <p className="mt-5 font-serif text-2xl leading-snug text-foreground sm:text-3xl">
                          Этот кадр я не показываю просто так.
                        </p>
                        <p className="mx-auto mt-3 max-w-xs text-sm leading-relaxed text-foreground/60">
                          Сначала — один честный ответ. Потом — то, что
                          останется между нами.
                        </p>

                        <button
                          type="button"
                          onClick={() => setStage("question")}
                          className={cn(
                            buttonVariants({ size: "lg" }),
                            "mt-9 h-12 gap-2.5 rounded-full px-7 text-[0.7rem] font-semibold uppercase tracking-[0.2em]"
                          )}
                        >
                          <LockKeyhole className="size-4" />
                          Снять печать
                        </button>

                        <p className="mt-5 text-[0.58rem] uppercase tracking-[0.3em] text-gold-muted/70">
                          Только между нами
                        </p>
                      </div>
                    ) : (
                      <div className="relative w-full">
                        <p className="text-[0.6rem] uppercase tracking-[0.34em] text-gold-muted">
                          Александра спрашивает
                        </p>
                        <p className="mt-6 font-serif text-2xl leading-snug text-foreground sm:text-[1.75rem]">
                          Скажи честно: ты уже думал обо мне сегодня?
                        </p>
                        <p className="mx-auto mt-3 max-w-xs text-sm leading-relaxed text-foreground/55">
                          Любой ответ считается правильным.
                        </p>

                        <div className="mt-8 space-y-3">
                          {answers.map((answer) => (
                            <button
                              key={answer}
                              type="button"
                              onClick={() => setStage("revealed")}
                              className="group flex w-full items-center justify-between gap-4 rounded-xl border border-gold/30 bg-black/20 px-5 py-3.5 text-left text-sm text-foreground/85 transition-all duration-300 hover:border-gold/60 hover:bg-gold/[0.08] hover:text-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60 sm:text-base"
                            >
                              <span>{answer}</span>
                              <ArrowRight className="size-4 shrink-0 text-gold-muted transition-transform group-hover:translate-x-0.5 group-hover:text-gold" />
                            </button>
                          ))}
                        </div>

                        <button
                          type="button"
                          onClick={() => setStage("sealed")}
                          className="mt-6 text-[0.6rem] uppercase tracking-[0.28em] text-gold-muted transition-colors hover:text-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60"
                        >
                          Не сейчас
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center text-center">
          <p className="max-w-md font-serif text-lg leading-relaxed text-foreground/80 sm:text-xl">
            Ты уже знаешь, чего хочешь. Осталось только выбрать.
          </p>
          <ScrollAnchor
            targetId="catalog"
            className={cn(
              buttonVariants({ variant: "outline", size: "lg" }),
              "group mt-6 h-12 gap-3 rounded-full border-gold/40 bg-transparent px-8 text-[0.7rem] font-semibold uppercase tracking-[0.2em] text-foreground/85 hover:bg-gold/10 hover:text-gold"
            )}
          >
            Выбрать услугу
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
          </ScrollAnchor>
        </div>
      </div>
    </section>
  );
}
