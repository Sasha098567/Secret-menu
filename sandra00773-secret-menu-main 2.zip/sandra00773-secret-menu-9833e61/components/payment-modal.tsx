"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Check, CheckCircle2, Copy, Mail, Send, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { buttonVariants } from "@/components/ui/button-variants";
import {
  buildEmailLink,
  buildOrderMessage,
  buildTelegramChatLink,
  getOrderTotal,
  PAYMENT_CARD_HOLDER,
  PAYMENT_CARD_NUMBER,
  type OrderSummary,
} from "@/lib/order";
import { cn } from "@/lib/utils";

type PaymentModalProps = {
  order: OrderSummary;
  onClose: () => void;
};

export function PaymentModal({ order, onClose }: PaymentModalProps) {
  const [stage, setStage] = useState<"payment" | "ready">("payment");
  const [isCopied, setIsCopied] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);
  const copyTimeoutRef = useRef<number | null>(null);

  const closeModal = useCallback(() => {
    onClose();
  }, [onClose]);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    dialogRef.current?.focus();

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeModal();
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);

      if (copyTimeoutRef.current !== null) {
        window.clearTimeout(copyTimeoutRef.current);
      }
    };
  }, [closeModal]);

  const handleCopyCard = async () => {
    try {
      await navigator.clipboard.writeText(PAYMENT_CARD_NUMBER);
      setIsCopied(true);
      toast.success("Номер карты скопирован");

      if (copyTimeoutRef.current !== null) {
        window.clearTimeout(copyTimeoutRef.current);
      }

      copyTimeoutRef.current = window.setTimeout(() => {
        setIsCopied(false);
        copyTimeoutRef.current = null;
      }, 2000);
    } catch {
      toast.error("Не удалось скопировать номер карты");
    }
  };

  const message = buildOrderMessage(order);
  const total = getOrderTotal(order.services);
  const telegramLink = buildTelegramChatLink(message);

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-black/80 px-5 py-10 animate-in fade-in duration-300"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) closeModal();
      }}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="payment-modal-title"
        tabIndex={-1}
        className="relative w-full max-w-lg border border-gold/35 bg-wine-deep p-6 shadow-2xl animate-in zoom-in-95 duration-300 focus:outline-none sm:p-9"
      >
        <button
          type="button"
          onClick={closeModal}
          aria-label="Закрыть окно оплаты"
          className="absolute right-4 top-4 flex size-8 items-center justify-center rounded-full text-foreground/50 transition-colors hover:text-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60"
        >
          <X className="size-4" />
        </button>

        <p className="text-[0.62rem] uppercase tracking-[0.32em] text-gold-muted">
          Оплата Александре
        </p>
        <h3
          id="payment-modal-title"
          className="mt-3 pr-8 font-serif text-2xl font-medium tracking-wide text-foreground sm:text-3xl"
        >
          {stage === "payment"
            ? "Остался последний шаг"
            : "Заявка сформирована"}
        </h3>

        <div className="mt-6 border border-gold/25 bg-black/25 p-5">
          <p className="text-[0.62rem] uppercase tracking-[0.28em] text-gold-muted">
            Номер карты
          </p>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
            <p className="font-serif text-xl tracking-[0.16em] text-gold sm:text-2xl">
              {PAYMENT_CARD_NUMBER}
            </p>
            <Button
              type="button"
              onClick={handleCopyCard}
              aria-label="Скопировать номер карты"
              className="h-9 shrink-0 gap-2 rounded-full border border-gold/40 bg-transparent px-4 text-[0.62rem] font-semibold uppercase tracking-[0.18em] text-gold hover:bg-gold/10"
            >
              {isCopied ? (
                <Check className="size-3.5" />
              ) : (
                <Copy className="size-3.5" />
              )}
              {isCopied ? "Скопировано" : "Скопировать"}
            </Button>
          </div>
          <p className="mt-3 font-serif text-lg italic text-foreground/80">
            {PAYMENT_CARD_HOLDER}
          </p>
        </div>

        <div className="mt-5 flex items-center justify-between gap-4 border-b border-gold/15 pb-4 text-sm">
          <span className="text-foreground/60">
            Услуг: {order.services.length}
          </span>
          <span className="font-serif text-xl text-gold">{total} $</span>
        </div>

        {stage === "payment" ? (
          <div className="mt-6">
            <p className="text-sm leading-relaxed text-foreground/60">
              Переведи сумму на карту Александры. Нажми «Подтвердить заказ» —
              откроется чат с @sandra_826 в Telegram с уже заполненным текстом
              заявки: все услуги, дата и твой контакт. Останется нажать
              «Отправить».
            </p>

            <a
              href={telegramLink}
              target="_blank"
              rel="noreferrer"
              onClick={() => setStage("ready")}
              className={cn(
                buttonVariants(),
                "mt-6 h-12 w-full gap-2 rounded-full px-7 text-[0.72rem] font-semibold uppercase tracking-[0.18em]"
              )}
            >
              Подтвердить заказ
              <Check className="size-4" />
            </a>
          </div>
        ) : (
          <div className="mt-6">
            <div
              role="status"
              className="flex items-start gap-3 border border-gold/30 bg-gold/[0.08] px-4 py-3"
            >
              <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-gold" />
              <div>
                <p className="text-sm font-medium text-gold">
                  Заявка сформирована
                </p>
                <p className="mt-1 text-xs leading-relaxed text-foreground/60">
                  Открой чат с @sandra_826 в Telegram — сообщение уже заполнено,
                  останется нажать «Отправить». Или отправь заявку на почту.
                </p>
              </div>
            </div>

            <div className="mt-5">
              <p className="text-[0.62rem] uppercase tracking-[0.28em] text-gold-muted">
                Готовое сообщение
              </p>
              <pre className="mt-3 max-h-52 overflow-y-auto border border-gold/20 bg-black/30 p-4 font-sans text-xs leading-relaxed whitespace-pre-wrap text-foreground/80">
                {message}
              </pre>
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <a
                href={telegramLink}
                target="_blank"
                rel="noreferrer"
                className={cn(
                  buttonVariants(),
                  "h-11 gap-2 rounded-full px-5 text-[0.66rem] font-semibold uppercase tracking-[0.16em]"
                )}
              >
                <Send className="size-4" />В Telegram
              </a>
              <a
                href={buildEmailLink(message)}
                className={cn(
                  buttonVariants({ variant: "outline" }),
                  "h-11 gap-2 rounded-full border-gold/40 bg-transparent px-5 text-[0.66rem] font-semibold uppercase tracking-[0.16em] text-gold hover:bg-gold/10 hover:text-gold"
                )}
              >
                <Mail className="size-4" />
                На почту
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
