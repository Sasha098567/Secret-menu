"use client";

import { useMemo, useRef, useState } from "react";
import type { FormEvent } from "react";
import { CalendarDays, Plus, Send, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PaymentModal } from "@/components/payment-modal";
import {
  allServices,
  createCustomIdeaService,
  customIdeaServiceId,
  hasPrice,
  type CatalogService,
} from "@/lib/data";
import {
  formatMeetingDate,
  getOrderTotal,
  type OrderSummary,
} from "@/lib/order";
import { cn } from "@/lib/utils";

type ServiceRequestFormProps = {
  selectedIds: string[];
  onToggleService: (serviceId: string) => void;
  customIdea: string;
  isCustomIdeaSelected: boolean;
  onToggleCustomIdea: () => void;
};

type FormErrors = {
  services?: string;
  contact?: string;
};

export function ServiceRequestForm({
  selectedIds,
  onToggleService,
  customIdea,
  isCustomIdeaSelected,
  onToggleCustomIdea,
}: ServiceRequestFormProps) {
  const [meetingDate, setMeetingDate] = useState("");
  const [contact, setContact] = useState("");
  const [errors, setErrors] = useState<FormErrors>({});
  const [order, setOrder] = useState<OrderSummary | null>(null);
  const servicesRef = useRef<HTMLFieldSetElement>(null);
  const contactRef = useRef<HTMLInputElement>(null);

  const customIdeaService = useMemo(
    () =>
      isCustomIdeaSelected && customIdea.trim()
        ? createCustomIdeaService(customIdea.trim())
        : null,
    [customIdea, isCustomIdeaSelected]
  );

  const selectedServices = useMemo(() => {
    const catalogSelected = allServices.filter((service) =>
      selectedIds.includes(service.id)
    );

    return customIdeaService
      ? [...catalogSelected, customIdeaService]
      : catalogSelected;
  }, [selectedIds, customIdeaService]);

  const availableServices = useMemo(
    () => allServices.filter((service) => !selectedIds.includes(service.id)),
    [selectedIds]
  );

  const total = useMemo(
    () => getOrderTotal(selectedServices),
    [selectedServices]
  );

  const handleToggleService = (serviceId: string) => {
    onToggleService(serviceId);
    setErrors((current) => ({ ...current, services: undefined }));
  };

  const handleRemoveSelectedService = (service: CatalogService) => {
    if (service.id === customIdeaServiceId) {
      onToggleCustomIdea();
    } else {
      onToggleService(service.id);
    }

    setErrors((current) => ({ ...current, services: undefined }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const nextErrors: FormErrors = {};

    if (selectedServices.length === 0) {
      nextErrors.services = "Выбери хотя бы одну услугу из меню.";
    }

    if (!contact.trim()) {
      nextErrors.contact = "Укажи контакт: Telegram, почту или телефон.";
    }

    if (nextErrors.services || nextErrors.contact) {
      setErrors(nextErrors);

      if (nextErrors.services) {
        servicesRef.current?.focus();
      } else {
        contactRef.current?.focus();
      }

      return;
    }

    setErrors({});

    setOrder({
      services: selectedServices,
      dateLabel: formatMeetingDate(meetingDate),
      contact: contact.trim(),
    });
  };

  return (
    <article
      id="request"
      className="mt-16 scroll-mt-14 border border-gold/25 bg-black/25 p-6 sm:p-8"
    >
      <div className="max-w-xl">
        <p className="text-[0.68rem] uppercase tracking-[0.32em] text-gold-muted">
          Заявка
        </p>
        <h3 className="mt-3 font-serif text-2xl font-medium tracking-wide text-foreground sm:text-3xl">
          Собери свой вечер
        </h3>
        <p className="mt-3 text-sm leading-relaxed text-foreground/60">
          Выбери одну или несколько услуг в каталоге или прямо здесь. Набор
          можно менять в любой момент — стоимость пересчитается сама.
        </p>
      </div>

      <form onSubmit={handleSubmit} noValidate className="mt-8 space-y-8">
        <fieldset
          ref={servicesRef}
          tabIndex={-1}
          aria-describedby={
            errors.services ? "request-services-error" : undefined
          }
          className="min-w-0 focus:outline-none"
        >
          <legend className="text-[0.68rem] uppercase tracking-[0.28em] text-gold-muted">
            Услуги
          </legend>

          {selectedServices.length > 0 ? (
            <ul className="mt-4 flex flex-wrap gap-2">
              {selectedServices.map((service) => (
                <li key={service.id}>
                  <span className="inline-flex items-center gap-2 border border-gold/40 bg-gold/[0.08] py-2 pl-3 pr-2 text-sm text-gold">
                    <span className="leading-tight">{service.name}</span>
                    {hasPrice(service) ? (
                      <span className="text-xs text-gold-muted">
                        {service.price} $
                      </span>
                    ) : null}
                    <button
                      type="button"
                      onClick={() => handleRemoveSelectedService(service)}
                      aria-label={`Убрать услугу «${service.name}»`}
                      className="flex size-6 shrink-0 items-center justify-center rounded-full text-gold-muted transition-colors hover:bg-gold/15 hover:text-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60"
                    >
                      <X className="size-3.5" />
                    </button>
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-4 border border-dashed border-gold/25 px-4 py-3 text-sm leading-relaxed text-foreground/50">
              Пока ничего не выбрано. Отметь услуги в каталоге или добавь их
              кнопками ниже.
            </p>
          )}

          <div className="mt-5 border-t border-gold/15 pt-5">
            <p className="text-[0.62rem] uppercase tracking-[0.24em] text-gold-muted">
              Добавить услугу
            </p>

            {availableServices.length > 0 ? (
              <div className="mt-3 flex flex-wrap gap-2">
                {availableServices.map((service) => (
                  <button
                    key={service.id}
                    type="button"
                    onClick={() => handleToggleService(service.id)}
                    className="group inline-flex items-center gap-2 border border-gold/20 px-3 py-2 text-left text-xs leading-tight text-foreground/70 transition-colors hover:border-gold/50 hover:bg-gold/[0.05] hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60"
                  >
                    <Plus className="size-3.5 shrink-0 text-gold-muted transition-colors group-hover:text-gold" />
                    <span>{service.name}</span>
                    {hasPrice(service) ? (
                      <span className="text-gold-muted">{service.price} $</span>
                    ) : null}
                  </button>
                ))}
              </div>
            ) : (
              <p className="mt-3 text-xs leading-relaxed text-foreground/50">
                Все услуги из каталога уже в наборе.
              </p>
            )}
          </div>

          {errors.services ? (
            <p
              id="request-services-error"
              role="alert"
              className="mt-4 text-xs leading-relaxed text-destructive"
            >
              {errors.services}
            </p>
          ) : null}
        </fieldset>

        <div className="grid gap-5 sm:grid-cols-2">
          <div className="min-w-0">
            <label
              htmlFor="request-date"
              className="flex items-center gap-2 text-[0.68rem] uppercase tracking-[0.28em] text-gold-muted"
            >
              <CalendarDays className="size-3.5 text-gold-muted" />
              Дата встречи
            </label>
            <Input
              id="request-date"
              type="date"
              value={meetingDate}
              onChange={(event) => setMeetingDate(event.target.value)}
              className="mt-2 h-11 rounded-none border-gold/30 bg-wine-deep px-3 text-sm text-foreground [color-scheme:dark] focus-visible:border-gold focus-visible:ring-2 focus-visible:ring-gold/40"
            />
            <p className="mt-2 text-xs leading-relaxed text-foreground/45">
              Можно уточнить позже, если пока не решил.
            </p>
          </div>

          <div className="min-w-0">
            <label
              htmlFor="request-contact"
              className="block text-[0.68rem] uppercase tracking-[0.28em] text-gold-muted"
            >
              Контакт для связи
            </label>
            <Input
              ref={contactRef}
              id="request-contact"
              type="text"
              value={contact}
              onChange={(event) => {
                setContact(event.target.value);
                setErrors((current) => ({ ...current, contact: undefined }));
              }}
              aria-invalid={Boolean(errors.contact)}
              aria-describedby={
                errors.contact ? "request-contact-error" : undefined
              }
              placeholder="Telegram, почта или телефон"
              className={cn(
                "mt-2 h-11 rounded-none border-gold/30 bg-wine-deep px-3 text-sm text-foreground placeholder:text-foreground/35 focus-visible:border-gold focus-visible:ring-2 focus-visible:ring-gold/40",
                errors.contact &&
                  "border-destructive focus-visible:ring-destructive/40"
              )}
            />
            {errors.contact ? (
              <p
                id="request-contact-error"
                role="alert"
                className="mt-2 text-xs leading-relaxed text-destructive"
              >
                {errors.contact}
              </p>
            ) : (
              <p className="mt-2 text-xs leading-relaxed text-foreground/45">
                Напиши туда, где тебе удобно ответить.
              </p>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-5 border-t border-gold/15 pt-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-[0.62rem] uppercase tracking-[0.28em] text-gold-muted">
              Общая стоимость
            </p>
            <p
              aria-live="polite"
              className="mt-2 font-serif text-3xl text-gold"
            >
              {total} $
            </p>
            <p className="mt-1 text-xs text-foreground/50">
              Выбрано услуг: {selectedServices.length}
            </p>
          </div>

          <Button
            type="submit"
            size="lg"
            className="h-12 shrink-0 gap-2 rounded-full px-7 text-[0.72rem] font-semibold uppercase tracking-[0.18em]"
          >
            Отправить запрос
            <Send className="size-4" />
          </Button>
        </div>
      </form>

      {order ? (
        <PaymentModal order={order} onClose={() => setOrder(null)} />
      ) : null}
    </article>
  );
}
