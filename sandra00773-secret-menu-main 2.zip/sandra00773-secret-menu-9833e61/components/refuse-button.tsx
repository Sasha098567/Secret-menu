"use client";

import { useCallback, useState } from "react";
import { Check, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  allServices,
  autoAssignedServiceId,
  hasPrice,
  refusalExcuses,
} from "@/lib/data";

type RefuseButtonProps = {
  selectedIds: string[];
  onAutoSelect: (serviceId: string) => void;
};

const AUTO_SELECT_AFTER = 4;

export function RefuseButton({ selectedIds, onAutoSelect }: RefuseButtonProps) {
  const [clicks, setClicks] = useState(0);
  const [excuseIndex, setExcuseIndex] = useState(-1);
  const [pickedServiceId, setPickedServiceId] = useState<string | null>(null);

  const autoService = allServices.find(
    (service) => service.id === autoAssignedServiceId
  );
  const pickedService = pickedServiceId
    ? allServices.find((service) => service.id === pickedServiceId)
    : null;
  const isAlreadySelected = selectedIds.includes(autoAssignedServiceId);

  const excuse =
    excuseIndex >= 0
      ? refusalExcuses[excuseIndex % refusalExcuses.length]
      : null;

  const handleRefuse = useCallback(() => {
    setExcuseIndex((current) => (current + 1) % refusalExcuses.length);
    setClicks((current) => current + 1);

    if (clicks + 1 >= AUTO_SELECT_AFTER && autoService) {
      if (pickedServiceId !== autoService.id) {
        setPickedServiceId(autoService.id);
      }
      onAutoSelect(autoService.id);
    }
  }, [autoService, clicks, onAutoSelect, pickedServiceId]);

  const showPicked = clicks >= AUTO_SELECT_AFTER && Boolean(pickedService);

  return (
    <article className="relative mt-14 overflow-hidden border border-gold/25 bg-black/25 p-6 sm:p-8">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 size-48 rounded-full bg-gold/5 blur-2xl"
      />

      <div className="relative flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
        <div className="max-w-xl">
          <p className="text-[0.62rem] uppercase tracking-[0.32em] text-gold-muted">
            Проверка на сговорчивость
          </p>
          <h3 className="mt-3 font-serif text-2xl font-medium tracking-wide text-foreground sm:text-3xl">
            Отказаться нельзя
          </h3>
          <p className="mt-3 text-sm leading-relaxed text-foreground/60">
            Кнопка «Я передумал» работает по особому меню: каждое нажатие —
            новая причина, почему передумать не получится.
          </p>
        </div>

        <Button
          type="button"
          size="lg"
          onClick={handleRefuse}
          className="h-12 shrink-0 gap-2 rounded-full px-7 text-[0.72rem] font-semibold uppercase tracking-[0.18em]"
        >
          <RotateCcw className="size-4" />Я передумал
        </Button>
      </div>

      <div aria-live="polite" className="relative mt-6 space-y-3">
        {excuse ? (
          <p className="border-l-2 border-gold/50 bg-gold/[0.04] px-4 py-3 font-serif text-lg italic leading-relaxed text-foreground/90 animate-in fade-in slide-in-from-bottom-2 duration-300">
            «{excuse}»
          </p>
        ) : (
          <p className="text-sm leading-relaxed text-foreground/45">
            Нажми и посмотри, что тебе ответят. Спойлер: «нет» не предусмотрено.
          </p>
        )}

        {showPicked && pickedService ? (
          <p className="flex items-start gap-3 border border-gold/40 bg-gold/[0.08] px-4 py-3 text-sm leading-relaxed text-gold animate-in fade-in slide-in-from-bottom-2 duration-300">
            <Check className="mt-0.5 size-4 shrink-0" />
            <span>
              Выбор сделан. «{pickedService.name}»
              {hasPrice(pickedService) ? ` — ${pickedService.price} $` : ""} —
              уже в заявке. Осталось только согласиться.
            </span>
          </p>
        ) : null}

        {showPicked && isAlreadySelected ? (
          <p className="text-xs leading-relaxed text-foreground/45">
            Услугу можно убрать в форме, но кнопка «Я передумал» всё равно
            знает, что нужно делать.
          </p>
        ) : null}
      </div>
    </article>
  );
}
