import { Quote, Star } from "lucide-react";
import { guestReviews } from "@/lib/data";
import { cn } from "@/lib/utils";

function Rating({
  value,
  max,
  label,
}: {
  value: number;
  max: number;
  label: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <span
        className="flex items-center gap-0.5 text-gold"
        role="img"
        aria-label={`${label}: ${value} из ${max}`}
      >
        {Array.from({ length: max }, (_, index) => (
          <Star
            key={index}
            aria-hidden
            className={cn(
              "size-3.5",
              index < value ? "fill-gold" : "fill-transparent text-gold/30"
            )}
            strokeWidth={1.25}
          />
        ))}
      </span>
      <span className="text-[0.62rem] uppercase tracking-[0.18em] text-gold-muted">
        {value} / {max}
      </span>
    </div>
  );
}

export function GuestReviews() {
  const average =
    guestReviews.reduce((sum, review) => sum + review.rating, 0) /
    guestReviews.length;

  return (
    <section
      id="reviews"
      className="relative scroll-mt-14 overflow-hidden border-t border-gold/15 bg-wine-deep"
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute inset-x-6 top-6 bottom-6 border border-gold/10 sm:inset-x-10 sm:top-10 sm:bottom-10" />
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl px-6 py-20 sm:py-28">
        <div className="text-center">
          <p className="text-[0.68rem] uppercase tracking-[0.42em] text-gold-muted">
            Анонимные впечатления
          </p>
          <h2 className="mt-4 font-serif text-3xl font-medium tracking-wide text-foreground sm:text-4xl">
            Отзывы
          </h2>
          <div
            aria-hidden
            className="mt-5 flex items-center justify-center gap-3"
          >
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-gold/60" />
            <span className="size-1.5 rotate-45 border border-gold/50" />
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-gold/60" />
          </div>
          <p className="mx-auto mt-5 max-w-lg text-sm leading-relaxed text-foreground/60">
            Впечатления анонимны — о настроении вечера и уровне сервиса. Без
            имён, но с искренними эмоциями.
          </p>

          <div className="mx-auto mt-7 flex w-fit items-center gap-4 border border-gold/25 px-5 py-3">
            <span className="font-serif text-2xl text-gold">
              {average.toFixed(1).replace(".", ",")}
            </span>
            <span aria-hidden className="h-7 w-px bg-gold/25" />
            <span className="text-left">
              <span className="block text-[0.6rem] uppercase tracking-[0.24em] text-gold-muted">
                Средняя оценка сервиса
              </span>
              <span className="mt-0.5 block text-xs text-foreground/55">
                По {guestReviews.length} анонимным отзывам
              </span>
            </span>
          </div>
        </div>

        <ul className="mt-14 grid gap-5 md:grid-cols-3">
          {guestReviews.map((review) => (
            <li key={review.id} className="h-full">
              <article className="group relative flex h-full flex-col border border-gold/20 bg-black/25 p-6 transition-colors duration-300 hover:border-gold/45 hover:bg-gold/[0.04]">
                <Quote
                  aria-hidden
                  className="absolute top-5 right-5 size-6 text-gold/25 transition-colors duration-300 group-hover:text-gold/40"
                  strokeWidth={1.25}
                />

                <p className="text-[0.62rem] uppercase tracking-[0.26em] text-gold-muted">
                  {review.author}
                </p>

                <p className="mt-5 font-serif text-lg italic leading-snug text-gold/90">
                  {review.highlight}
                </p>

                <p className="mt-3 flex-1 text-sm leading-relaxed text-foreground/65">
                  {review.text}
                </p>

                <div className="mt-6 border-t border-gold/15 pt-4">
                  <p className="text-[0.6rem] uppercase tracking-[0.22em] text-gold-muted">
                    Уровень сервиса
                  </p>
                  <div className="mt-2">
                    <Rating
                      value={review.rating}
                      max={review.maxRating}
                      label={`Оценка уровня сервиса, ${review.author}`}
                    />
                  </div>
                </div>
              </article>
            </li>
          ))}
        </ul>

        <p className="mt-8 text-center text-[0.62rem] uppercase tracking-[0.24em] text-foreground/40">
          Отзывы анонимны
        </p>
      </div>
    </section>
  );
}
