import {
  CalendarCheck,
  MessagesSquare,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

type Rule = {
  icon: LucideIcon;
  title: string;
  text: string;
};

const rules: Rule[] = [
  {
    icon: ShieldCheck,
    title: "Безопасность и комфорт",
    text: "Всё по любви и по согласию. Границы обсуждаем заранее — как взрослые, а не как соседи по коммуналке.",
  },
  {
    icon: Sparkles,
    title: "Эстетическое удовольствие",
    text: "Свет, музыка, детали — красота входит в стоимость. Хочется красиво? Это не капризы, это высокие стандарты.",
  },
  {
    icon: MessagesSquare,
    title: "Уважительное общение",
    text: "Без давления, грубости и торга. Вежливость у нас бесплатна, но строго обязательна.",
  },
  {
    icon: CalendarCheck,
    title: "Конфиденциальность и бронь",
    text: "Контакты и подробности остаются между нами. Время — по записи: предупреди заранее, и оно твоё.",
  },
];

export function VenueRules() {
  return (
    <div id="venue-rules" className="mt-16 scroll-mt-14">
      <div className="text-center">
        <p className="text-[0.68rem] uppercase tracking-[0.42em] text-gold-muted">
          Дресс-код не нужен
        </p>
        <h3 className="mt-4 font-serif text-2xl font-medium tracking-wide text-foreground sm:text-3xl">
          Правила заведения
        </h3>
        <div
          aria-hidden
          className="mx-auto mt-5 flex max-w-max items-center gap-3"
        >
          <span className="h-px w-10 bg-gradient-to-r from-transparent to-gold/60" />
          <span className="size-1.5 rotate-45 border border-gold/50" />
          <span className="h-px w-10 bg-gradient-to-l from-transparent to-gold/60" />
        </div>
      </div>

      <ul className="mt-8 grid gap-4 sm:grid-cols-2">
        {rules.map((rule, index) => {
          const Icon = rule.icon;

          return (
            <li key={rule.title} className="h-full">
              <article className="group relative flex h-full flex-col border border-gold/25 bg-black/25 p-5 transition-colors duration-300 hover:border-gold/50 hover:bg-gold/[0.05] sm:p-6">
                <span
                  aria-hidden
                  className="font-serif text-xs italic text-gold-muted"
                >
                  {String(index + 1).padStart(2, "0")}
                </span>

                <span className="mt-3 flex size-10 items-center justify-center rounded-full border border-gold/30 text-gold-muted transition-colors duration-300 group-hover:border-gold/60 group-hover:text-gold">
                  <Icon className="size-4" strokeWidth={1.5} />
                </span>

                <h4 className="mt-4 font-serif text-xl font-medium tracking-wide text-foreground">
                  {rule.title}
                </h4>
                <p className="mt-2 text-sm leading-relaxed text-foreground/65">
                  {rule.text}
                </p>
              </article>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
