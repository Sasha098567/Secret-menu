"use client";

import type { MouseEvent, ReactNode } from "react";

type ScrollAnchorProps = {
  targetId: string;
  className?: string;
  children: ReactNode;
};

export function ScrollAnchor({
  targetId,
  className,
  children,
}: ScrollAnchorProps) {
  const handleClick = (event: MouseEvent<HTMLAnchorElement>) => {
    const target = document.getElementById(targetId);

    if (!target) {
      return;
    }

    event.preventDefault();

    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    target.scrollIntoView({
      behavior: prefersReducedMotion ? "auto" : "smooth",
      block: "start",
    });

    const nextHash = `#${targetId}`;

    if (window.location.hash !== nextHash) {
      window.history.pushState(null, "", nextHash);
    }
  };

  return (
    <a href={`#${targetId}`} onClick={handleClick} className={className}>
      {children}
    </a>
  );
}
