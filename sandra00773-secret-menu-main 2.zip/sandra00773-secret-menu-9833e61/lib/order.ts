import { hasPrice, type CatalogService } from "@/lib/data";

export const PAYMENT_CARD_NUMBER = "4649 9012 2559 6582";
export const PAYMENT_CARD_HOLDER = "Александра";
export const ALEXANDRA_EMAIL = "alexandra@secretmenu.club";
export const ALEXANDRA_TELEGRAM_USERNAME = "sandra_826";

export type OrderSummary = {
  services: CatalogService[];
  dateLabel: string | null;
  contact: string;
};

export function formatMeetingDate(value: string) {
  if (!value) return null;

  const parsed = new Date(`${value}T00:00:00Z`);

  if (Number.isNaN(parsed.getTime())) return null;

  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(parsed);
}

export function getOrderTotal(services: CatalogService[]) {
  return services.reduce(
    (sum, service) => sum + (hasPrice(service) ? service.price : 0),
    0
  );
}

export function buildOrderMessage({
  services,
  dateLabel,
  contact,
}: OrderSummary) {
  const serviceLines = services.map((service) =>
    hasPrice(service)
      ? `— ${service.name} — ${service.price} $`
      : `— ${service.name}`
  );

  return [
    "Привет, Александра!",
    "",
    "Это заявка на встречу:",
    "",
    "Услуги:",
    ...serviceLines,
    "",
    `Итого: ${getOrderTotal(services)} $`,
    `Дата: ${dateLabel ?? "уточним позже"}`,
    `Контакт: ${contact}`,
    "",
    "От: Ник",
  ].join("\n");
}

export function buildTelegramChatLink(message: string) {
  const text = encodeURIComponent(message);

  return `https://t.me/${ALEXANDRA_TELEGRAM_USERNAME}?text=${text}`;
}

export function buildEmailLink(message: string) {
  const subject = encodeURIComponent(
    "Заявка на встречу от Ника — Секретное меню"
  );
  const body = encodeURIComponent(message);

  return `mailto:${ALEXANDRA_EMAIL}?subject=${subject}&body=${body}`;
}
