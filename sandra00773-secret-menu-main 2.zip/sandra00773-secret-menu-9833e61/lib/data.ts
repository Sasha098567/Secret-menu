export type CatalogService = {
  id: string;
  name: string;
  description: string;
  price?: number;
  categoryId: CatalogCategory["id"];
};

export function hasPrice(
  service: CatalogService
): service is CatalogService & { price: number } {
  return typeof service.price === "number";
}

export type CatalogCategory = {
  id: "soul" | "body";
  numeral: string;
  title: string;
  services: CatalogService[];
};

const soulServices: CatalogService[] = [
  {
    id: "hugs-and-kisses",
    name: "Обнимашки-целовашки",
    description:
      "Тёплые объятия и нежные поцелуи без спешки — начнём с самого главного.",
    categoryId: "soul",
  },
  {
    id: "loshytsa-date",
    name: "Свидание в Лошицком с какао",
    description:
      "Прогулка по парку, горячий какао и разговоры, от которых теплеет.",
    categoryId: "soul",
  },
  {
    id: "vibe-confectionery",
    name: "Вайбовая кондитерская с десертом",
    description:
      "Уютная кондитерская, красивый десерт и атмосфера, в которой время замедляется.",
    categoryId: "soul",
  },
  {
    id: "home-evening",
    name: "Домашний вечер с заказом еды и фильмом",
    description:
      "Любимая еда, фильм на выбор и вечер, где можно просто быть собой.",
    categoryId: "soul",
  },
  {
    id: "moscow-ring-road-rides",
    name: "Покатушки за МКАД",
    description: "Просто катаемся на машине, пока не надоест.",
    categoryId: "soul",
  },
  {
    id: "billiards",
    name: "Бильярд",
    description: "Я выигрываю, ты платишь за стол.",
    categoryId: "soul",
  },
  {
    id: "reels-in-the-car",
    name: "Рилсы в машине",
    description: "Листаем рилсы на парковке и ржём.",
    categoryId: "soul",
  },
  {
    id: "cinema-night",
    name: "Поход в кино",
    description: "Билеты, попкорн и спор о финале после сеанса.",
    categoryId: "soul",
  },
  {
    id: "gas-station-tea-trip",
    name: "Поездка за чаем на заправку",
    description: "Ночной чай в стаканчике с крышкой и разговоры обо всём.",
    categoryId: "soul",
  },
];

const bodyServices: CatalogService[] = [
  {
    id: "classic",
    name: "Классика",
    description: "минет",
    price: 20,
    categoryId: "body",
  },
  {
    id: "extreme",
    name: "Экстрим",
    description: "секс в машине",
    price: 20,
    categoryId: "body",
  },
  {
    id: "sport",
    name: "Спорт",
    description: "жёсткий секс дома",
    price: 20,
    categoryId: "body",
  },
  {
    id: "oil-massage",
    name: "Массаж с маслом",
    description:
      "Медленный массаж тёплым маслом, чтобы отпустить день и расслабиться.",
    price: 15,
    categoryId: "body",
  },
  {
    id: "finish-in-mouth",
    name: "Закончить в рот",
    description: "Финальный акцент вечера — так, как ты захочешь.",
    price: 20,
    categoryId: "body",
  },
];

export const serviceCatalog: CatalogCategory[] = [
  {
    id: "soul",
    numeral: "I",
    title: "Услуги для души",
    services: soulServices,
  },
  {
    id: "body",
    numeral: "II",
    title: "Услуги для тела",
    services: bodyServices,
  },
];

export const allServices: CatalogService[] = serviceCatalog.flatMap(
  (category) => category.services
);

export const customIdeaServiceId = "custom-idea";

export function createCustomIdeaService(idea: string): CatalogService {
  return {
    id: customIdeaServiceId,
    name: idea,
    description: "Своя идея — цена по договорённости.",
    categoryId: "soul",
  };
}

export const refusalExcuses: string[] = [
  "Отказаться нельзя — это же прямо в слогане написано.",
  "Поздно: это уже в счёте. Бухгалтерия не поймёт.",
  "Я уже надела чулки. Назад дороги нет.",
  "Столик забронирован, какао греется, свечи куплены.",
  "Я уже рассказала подругам. Не подводи меня перед коллективом.",
  "Кнопка «нет» сегодня на техобслуживании, так что не судьба.",
  "Я уже придумала весь вечер. Тебе осталось только прийти.",
  "Слушай, ты уже согласился. Просто ещё не знаешь об этом.",
];

export const autoAssignedServiceId = "classic";

export type VipService = {
  id: string;
  name: string;
  description: string;
  tag: string;
};

export const vipService: VipService = {
  id: "vip-strap-on",
  name: "Отстрапонить меня",
  description:
    "Особая VIP-позиция вне общего меню. Нажми, чтобы узнать, что об этом думает небо.",
  tag: "VIP",
};

export type ProtectionService = {
  id: string;
  title: string;
  name: string;
  description: string;
  price: string;
  prayer: string;
};

export const protectionService: ProtectionService = {
  id: "protection-gas-mask",
  title: "Индивидуальные средства защиты",
  name: "Противогаз",
  description:
    "Услуга Противогаз обязательно к выбору, если ты планируешь пердеть в моем присутствии, как обычно",
  price: "0 долларов, но с большим штрафом для твоей репутации",
  prayer:
    "Отче наш, иже еси в нашей квартире. Да приидет противогаз твой, да будет воля твоя: и в спальне, и на кухне. Хлеб наш насущный даждь нам днесь, но без гороха и капусты, ибо они — искушение. И прости Нику пуки его, якоже и мы прощаем ему носки на полу. И не введи его в соблазн пукнуть при свечах, но избави меня от амбре его. Ибо твое есть царство, и сила, и противогаз. Амин.",
};

export type GuestReview = {
  id: string;
  author: string;
  rating: number;
  maxRating: number;
  text: string;
  highlight: string;
};

export const guestReviews: GuestReview[] = [
  {
    id: "guest-1",
    author: "Отзыв №1",
    rating: 5,
    maxRating: 5,
    text: "Зашёл познакомиться и остался до позднего вечера. Всё продумано до мелочей: свет, музыка, разговоры — ощущение закрытого клуба, где тебя действительно ждали.",
    highlight: "Атмосфера, в которую хочется вернуться",
  },
  {
    id: "guest-2",
    author: "Отзыв №2",
    rating: 5,
    maxRating: 5,
    text: "Очень бережное внимание без лишней суеты. Задали пару вопросов, услышали пожелания и собрали вечер именно так, как мне хотелось. Редкое чувство — быть в центре внимания.",
    highlight: "Индивидуальный подход без шаблонов",
  },
  {
    id: "guest-3",
    author: "Отзыв №3",
    rating: 4,
    maxRating: 5,
    text: "Красиво, спокойно и по-настоящему тепло. Было ощущение, что попал в хорошо отрепетированный спектакль, где каждая деталь на своём месте. Ушёл с улыбкой и хорошим настроением.",
    highlight: "Детали, из которых складывается вечер",
  },
];
