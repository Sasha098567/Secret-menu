import { ArrowRight } from "lucide-react";
import { buttonVariants } from "@/components/ui/button-variants";
import { ScrollAnchor } from "@/components/scroll-anchor";
import { ServiceCatalog } from "@/components/service-catalog";
import { ForYou } from "@/components/for-you";
import { GuestReviews } from "@/components/guest-reviews";
import { cn } from "@/lib/utils";

export default function HomePage() {
  return (
    <>
      <section className="club-cover relative isolate overflow-hidden">
        <div aria-hidden className="pointer-events-none absolute inset-0">
          <div className="absolute inset-x-4 top-4 bottom-4 border border-gold/15 sm:inset-x-8 sm:top-8 sm:bottom-8" />
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent" />
        </div>

        <div className="relative z-10 mx-auto flex min-h-[calc(100svh-3.5rem)] max-w-4xl animate-in fade-in slide-in-from-bottom-4 flex-col items-center justify-center px-6 py-24 text-center duration-700">
          <p className="flex items-center gap-3 text-[0.68rem] font-medium uppercase tracking-[0.42em] text-gold">
            <span aria-hidden className="h-px w-8 bg-gold/50" />
            Секретное меню
            <span aria-hidden className="h-px w-8 bg-gold/50" />
          </p>

          <h1 className="mt-8 font-serif text-4xl font-medium leading-[0.95] tracking-[0.04em] text-foreground sm:text-6xl lg:text-7xl">
            Список услуг
            <span className="mt-2 block text-gold">для моего папочки</span>
          </h1>

          <div aria-hidden className="mt-9 flex items-center gap-4">
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-gold/60" />
            <span className="size-1.5 rotate-45 border border-gold/60" />
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-gold/60" />
          </div>

          <p className="mt-8 max-w-xl text-base leading-relaxed text-foreground/75 sm:text-lg">
            Выбери то, что хочешь сегодня. Отказаться нельзя
          </p>

          <ScrollAnchor
            targetId="catalog"
            className={cn(
              buttonVariants({ size: "lg" }),
              "group mt-10 h-12 gap-3 rounded-full px-8 text-[0.72rem] font-semibold uppercase tracking-[0.22em]"
            )}
          >
            Перейти к каталогу
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
          </ScrollAnchor>
        </div>
      </section>

      <ServiceCatalog />

      <ForYou />

      <GuestReviews />
    </>
  );
}
